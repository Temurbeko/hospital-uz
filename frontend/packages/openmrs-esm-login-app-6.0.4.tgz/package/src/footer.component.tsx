import React, { useCallback } from 'react';
import { Link, Tile } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { useConfig, ArrowRightIcon } from '@openmrs/esm-framework';
import { type ConfigSchema } from './config-schema';
import styles from './footer.scss';
import Logo from './login-logo.png';

interface Logo {
  src: string;
  alt?: string;
}

const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className={styles.footer}>
      <Tile className={styles.poweredByTile}>
        <div className={styles.poweredByContainer}>
          <span className={styles.poweredByText}>{t('builtWith', 'Built with')}</span>
          <img src={Logo} alt="ALFA-TEAM logo" className={styles.footerLogo} />
          <span className={styles.poweredByText}>
            {t('poweredBySubtext', 'An open-source medical record system and global community')}
          </span>
          <a
            className={styles.learnMoreButton}
            href="https://t.me/alpha_group_llc"
            rel="noopener noreferrer"
            target="_blank"
          >
            {t('learnMore', 'Learn more')}
            <ArrowRightIcon size={16} aria-label="Arrow right icon" />
          </a>
        </div>
      </Tile>
    </div>
  );
};

export default Footer;
