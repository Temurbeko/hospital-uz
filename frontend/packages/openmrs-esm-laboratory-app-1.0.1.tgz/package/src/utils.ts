export const getStatusColor = (fulfillerStatus: string) => {
  if (fulfillerStatus === 'COMPLETED') {
    return 'green';
  } else if (fulfillerStatus === 'IN_PROGRESS') {
    return 'orange';
  } else {
    return 'red';
  }
};

export function extractHiddenData(str: string) {
  const phone = str.match(/\{([^}]*)\}/);
  return {
    str: str.replace(/\{[^}]*\}/g, '').trim(),
    phone: phone ? phone[1] : null,
  };
}
