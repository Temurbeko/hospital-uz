import dayjs from 'dayjs';
import * as Yup from 'yup';
import mapValues from 'lodash/mapValues';
import { type RegistrationConfig } from '../../config-schema';
import { type FormValues } from '../patient-registration.types';
import { getDatetime } from '../patient-registration.resource';

export function getValidationSchema(config: RegistrationConfig) {
  return Yup.object({
    givenName: Yup.string().required('Ism majburiy'),
    familyName: Yup.string().required('Familiya majburiy'),
    additionalGivenName: Yup.string().when('addNameInLocalLanguage', {
      is: true,
      then: Yup.string().required('Ism majburiy'),
      otherwise: Yup.string().notRequired(),
    }),
    additionalFamilyName: Yup.string().when('addNameInLocalLanguage', {
      is: true,
      then: Yup.string().required('Familiya majburiy'),
      otherwise: Yup.string().notRequired(),
    }),
    gender: Yup.string()
      .oneOf(
        config.fieldConfigurations.gender.map((g) => g.value),
        'Jins aniqlanmagan',
      )
      .required('Jins majburiy'),
    birthdate: Yup.date().when('birthdateEstimated', {
      is: false,
      then: Yup.date()
        .required('Tug‘ilgan kun majburiy')
        .max(Date(), 'Tug‘ilgan kun kelajakda bo‘lishi mumkin emas')
        .min(
          dayjs().subtract(140, 'years').toDate(),
          'Tug‘ilgan kun 140 yildan ortiq bo‘lishi mumkin emas',
        )
        .nullable(),
      otherwise: Yup.date().nullable(),
    }),
    yearsEstimated: Yup.number().when('birthdateEstimated', {
      is: true,
      then: Yup.number()
        .required('Taxminiy yillar majburiy')
        .min(0, 'Taxminiy yillar manfiy bo‘lishi mumkin emas')
        .max(140, 'Taxminiy yillar 140 yildan ortiq bo‘lishi mumkin emas'),
      otherwise: Yup.number().nullable(),
    }),
    monthsEstimated: Yup.number().min(0, 'Taxminiy oylar manfiy bo‘lishi mumkin emas'),
    isDead: Yup.boolean(),
    deathDate: Yup.date()
      .when('isDead', {
        is: true,
        then: Yup.date().required('O‘lim sanasi majburiy'),
        otherwise: Yup.date().nullable(),
      })
      .max(new Date(), 'O‘lim sanasi kelajakda bo‘lishi mumkin emas')
      .test(
        'deathDate-after-birthdate',
        'O‘lim sanasi va vaqti tug‘ilgan kundan oldin bo‘lishi mumkin emas',
        function (value) {
          const { birthdate } = this.parent;
          if (birthdate && value) {
            return dayjs(value).isAfter(birthdate);
          }
          return true;
        },
      )
      .test('deathDate-before-today', 'O‘lim sanasi kelajakda bo‘lishi mumkin emas', function (value) {
        const { deathTime, deathTimeFormat } = this.parent;
        if (value && deathTime && deathTimeFormat && /^(1[0-2]|0?[1-9]):([0-5]?[0-9])$/.test(deathTime)) {
          return dayjs(getDatetime(value, deathTime, deathTimeFormat)).isBefore(dayjs());
        }
        return true;
      }),
    deathTime: Yup.string()
      .when('isDead', {
        is: true,
        then: Yup.string().required('O‘lim vaqti majburiy'),
        otherwise: Yup.string().nullable(),
      })
      .matches(/^(1[0-2]|0?[1-9]):([0-5]?[0-9])$/, 'Vaqt formati "hh:mm" ga mos kelmaydi'),

    deathTimeFormat: Yup.string()
      .when('isDead', {
        is: true,
        then: Yup.string().required('Vaqt formati majburiy'),
        otherwise: Yup.string().nullable(),
      })
      .oneOf(['AM', 'PM'], 'Vaqt formati noto‘g‘ri'),

    deathCause: Yup.string().when('isDead', {
      is: true,
      then: Yup.string().required('O‘lim sababi majburiy'),
      otherwise: Yup.string().nullable(),
    }),
    nonCodedCauseOfDeath: Yup.string().when(['isDead', 'deathCause'], {
      is: (isDead, deathCause) => isDead && deathCause === config.freeTextFieldConceptUuid,
      then: Yup.string().required('O‘lim sababi majburiy'),
      otherwise: Yup.string().nullable(),
    }),
    email: Yup.string().optional().email('Noto‘g‘ri email'),
    identifiers: Yup.lazy((obj: FormValues['identifiers']) =>
      Yup.object(
        mapValues(obj, () =>
          Yup.object({
            required: Yup.bool(),
            identifierValue: Yup.string().when('required', {
              is: true,
              then: Yup.string().required('Identifikator qiymati majburiy'),
              otherwise: Yup.string().notRequired(),
            }),
          }),
        ),
      ),
    ),
    relationships: Yup.array().of(
      Yup.object().shape({
        relatedPersonUuid: Yup.string().required(),
        relationshipType: Yup.string().required(),
      }),
    ),
  });
}
